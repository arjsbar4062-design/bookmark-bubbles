# Bookmark Bubbles

A tiny full-stack app with a dark, retro-bubble GUI that shows a bookmark tree on the right.
Two roles exist: **guest** and **owner**. Each has a password (no signup).

- Guest: view + export bookmarks, request owner rank.
- Owner: everything guest can, plus add/edit/delete/import, and review/resolve requests.

## Quick start

1) Install Node 18+
2) In a terminal:
```bash
cd bookmark-bubbles
npm install
cp .env.example .env
# Edit .env to set the initial plaintext passwords.
npm run dev
```
The server runs on http://localhost:3000

> On first run, the app hashes the passwords into the sqlite database and discards the plaintext.

## Importing bookmarks
Currently supports a simple JSON structure:
```json
{
  "title": "Root",
  "type": "folder",
  "children": [
    {"type":"link","title":"OpenAI","url":"https://openai.com"},
    {"type":"folder","title":"Docs","children":[
      {"type":"link","title":"MDN","url":"https://developer.mozilla.org"}
    ]}
  ]
}
```
Use the **Owner → Import** button to upload that JSON, or build the tree manually.

## Exporting
Guests and Owners can export to the same JSON format via the **Export** button.

## Resetting passwords
Change `OWNER_PASSWORD` or `GUEST_PASSWORD` in `.env` and delete `app.db` to fully reseed.
